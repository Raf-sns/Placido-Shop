
	Framework PLACIDO-SHOP
	Copyright © Raphaël Castello - 2018-2022
	Licence : "GNU AGPL" see: /LICENCE.txt
	-> web site : www.sns.pm
	-> Contact : contact@sns.pm

	Disclaimer :

	This software is provided as is without any warranty.
	You can copy, modify and resell it provided you make
	the modified code public and accessible to everyone under the same conditions.

	Contribution :
	You can contribute to the development, everyone is welcome !

	Security :
	See /security.txt

	See more on the Placido-Shop website : www.placido-shop.com
